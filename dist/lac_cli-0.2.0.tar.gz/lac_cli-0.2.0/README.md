<img src="https://raw.githubusercontent.com/iammcoding/lac-cli/main/lacicon.png" width="120" />

# lac-cli

lac-cli is a terminal shell built by [lacai.io](https://lacai.io) that brings AI directly into your command line. It autocompletes what you are typing in real time and understands plain English so you can describe what you want to do instead of memorizing commands.

**New in v0.2.0:** LacMind multi-model debate engine for complex queries and research tasks.

## Install

```bash
pip install lac-cli
```

## Getting Started

### Terminal Shell

Run `lac` to launch the shell. The first time you run it, a setup wizard will walk you through picking your AI provider and entering your API key. After that it goes straight to the shell every time.

```bash
lac
```

To redo the setup at any time:

```bash
lac --setup
```

To run without an internet connection or server:

```bash
lac --offline
```

To adjust autocomplete speed (default 150ms):

```bash
lac --debounce 50  # faster
lac --debounce 300 # slower
```

### LacMind Multi-Model Debate

Launch the web-based debate interface for complex queries:

```bash
lac mind
```

LacMind runs multiple AI models in a debate format where they challenge and refine each other's ideas, then vote on the best response. Perfect for research, code generation, and complex problem-solving.

## How It Works

### Terminal Shell

When you launch `lac`, it automatically starts a local server in the background that handles communication with your AI model. You do not need to start anything manually.

As you type, the shell sends your input to the AI and shows a suggested completion as ghost text. Press Tab to accept it. If you type something in plain English like "show all files bigger than 100mb", the shell converts it to the right command and asks you to confirm before running it.

The shell now tracks your session history (commands + outputs) and passes it to the AI for smarter context-aware suggestions.

### LacMind Debate Engine

LacMind orchestrates multiple AI models in a structured debate:

1. **Debate Rounds** - Models discuss and challenge each other's ideas sequentially
2. **Voting Phase** - Models vote on who provided the best reasoning
3. **Consensus Summary** - The winning model delivers the final response

Models are labeled anonymously (Model A, B, C) during debate to prevent bias. You can configure debate duration and select which models participate.

## Supported Providers

| Provider | Notes |
|----------|-------|
| `claude` | Anthropic API |
| `openai` | OpenAI API |
| `ollama` | Local models, no API key needed |
| `custom` | Any OpenAI compatible endpoint |

## Commands

### Terminal Shell

| Command | What it does |
|---------|--------------|
| `exit` | Quit the shell |
| `logout` | Delete your config and start fresh |
| `clear` | Clear the screen and session history |
| `cd <path>` | Change directory |

### LacMind

| Command | What it does |
|---------|--------------|
| `lac mind` | Launch LacMind web interface |
| Settings page | Add/edit/delete AI models |
| Duration selector | Set debate time (30s - 5min) |
| Stop button | End debate early |
| Export | Save conversations to PDF |

## Config

Your config is saved at `~/.lac/config.json` after setup. You can edit it directly if needed.

```json
{
  "provider": "claude",
  "api_key": "sk-...",
  "model": "claude-haiku-4-5-20251001",
  "base_url": "https://api.anthropic.com",
  "server": "ws://localhost:8765"
}
```

## Features

### Terminal Shell

- Ghost text autocomplete as you type, powered by your AI model
- Plain English to shell command conversion with confirmation before running
- Session history tracking - AI sees your recent commands and outputs for better context
- Configurable autocomplete debounce delay (--debounce flag)
- Works with any major AI provider or local models via Ollama
- Offline mode falls back to history and static completions
- Local server starts automatically in the background, no manual setup needed
- Logout clears your credentials and resets the config

### LacMind

- Multi-model debate engine with sequential discussion rounds
- Anonymous voting system to select best reasoning
- Real-time streaming of debate progress
- Conversation history with chat persistence
- Model management (add/edit/delete models)
- Configurable debate duration
- Stop debate early if consensus is reached
- Export conversations to PDF
- Clean, minimal dark theme UI

## About

lac-cli is part of [lacai.io](https://lacai.io). Built for developers who live in the terminal.

## License

MIT
